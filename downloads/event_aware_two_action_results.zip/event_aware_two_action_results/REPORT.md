# Two-action event-aware foraging experiment

## Summary

This simulation compares event-aware and event-blind average-reward MDP policies, a Zeraati-style event-free policy-iteration baseline adapted to this environment, an MVT-inspired threshold, and a tuned fixed threshold. All five agents use exactly two actions: **exploit** and **leave**.

The Zeraati-style baseline is **not an exact replication** of Zeraati et al. (2025). It adapts the paper's event-free state logic (current patch plus resource state) to this task's discretized resources and latent threat/recovery dynamics. The source paper instead models patch reward probabilities with its own depletion/replenishment dynamics and assumes known environmental statistics when solving the optimal policy.

## State and action spaces

The event-aware state is `s=(patch, resource_A, resource_B, resource_C, phase)`: 3 patches × 3 levels per patch × 5 phases = 405 states. The event-blind observation replaces the persistent phase with a transient boundary cue (`threat onset`, `recovery onset`, or `none`), yielding 243 observations. The Zeraati-style event-free observation is `(patch, resource_A, resource_B, resource_C)`, yielding 81 observations. The action set in every model is `{exploit, leave}`; leaving advances to the next patch in a fixed cycle A→B→C→A.

## Constructing the three MDPs

The event-aware MDP uses the full latent state and its known transition matrix. The event-blind and Zeraati-style models are constructed by aggregating latent states with the same observation. For each observation, compatible latent phases are mixed using a scenario-specific stationary phase prior calculated under a neutral 50:50 exploit/leave mixture, to obtain an approximate transition, reward, and duration model. The event-blind aggregation retains transient onset/recovery cues; the Zeraati-style model has no event cue. Because hidden phase affects dynamics and reward, these aggregated observations need not satisfy the Markov property exactly. This is an explicit approximation, not a property guaranteed by the original Zeraati paper.

## Average-reward policy iteration

For each policy, evaluation solves `h(s)=R_pi(s)-rho_pi*T_pi(s)+sum P_pi(s,s')h(s')`. Improvement selects `argmax_a [R(s,a)-rho_pi*T(s,a)+sum P(s'|s,a)h(s')]`. Iteration stops when the greedy action map stops changing. The same solver and stopping rule are used for all three MDP policies; only their state representations and transition/reward models differ. Threshold baselines do not use policy iteration.

## Environmental event mechanism

Threat onset is generated stochastically and independently of the immediate food-reward outcome. During threat onset/ongoing phases, exploitation incurs an illustrative danger cost; leaving advances to the next patch and makes the threat more likely to resolve. These are task-design assumptions, not empirical estimates.

## Methods and comparison

The run used 20 evaluation seeds per model and scenario, 3000 decision steps per seed, and 200 warm-up steps excluded from evaluation. Fixed thresholds were tuned on separate training seeds. The MVT-inspired threshold is based on the Zeraati-style event-free model's estimated average reward rate, clipped to the prespecified interval [0.05, 0.80].

## Results

Mean reward per unit time and approximate 95% confidence intervals across evaluation seeds:

| scenario                         | model                       |   mean_reward_rate |   ci95_approx_low |   ci95_approx_high |   policy_iterations |
|:---------------------------------|:----------------------------|-------------------:|------------------:|-------------------:|--------------------:|
| Reference                        | Event-aware PI              |          0.325041  |         0.322073  |          0.328008  |                   7 |
| Reference                        | Event-blind PI              |          0.274095  |         0.269707  |          0.278483  |                   8 |
| Reference                        | Zeraati-style event-free PI |          0.254849  |         0.250107  |          0.259591  |                   7 |
| Reference                        | MVT-inspired threshold      |          0.180157  |         0.173574  |          0.186739  |                 nan |
| Reference                        | Best fixed threshold        |          0.259985  |         0.256232  |          0.263739  |                 nan |
| High threat                      | Event-aware PI              |          0.292901  |         0.289777  |          0.296024  |                   8 |
| High threat                      | Event-blind PI              |          0.235004  |         0.233251  |          0.236756  |                   7 |
| High threat                      | Zeraati-style event-free PI |          0.215014  |         0.212516  |          0.217512  |                   6 |
| High threat                      | MVT-inspired threshold      |          0.0844556 |         0.0779243 |          0.0909868 |                 nan |
| High threat                      | Best fixed threshold        |          0.215618  |         0.21312   |          0.218117  |                 nan |
| Slow replenishment               | Event-aware PI              |          0.234752  |         0.231952  |          0.237553  |                   8 |
| Slow replenishment               | Event-blind PI              |          0.1926    |         0.189564  |          0.195636  |                   7 |
| Slow replenishment               | Zeraati-style event-free PI |          0.168934  |         0.165893  |          0.171976  |                   7 |
| Slow replenishment               | MVT-inspired threshold      |         -0.306215  |        -0.31855   |         -0.293881  |                 nan |
| Slow replenishment               | Best fixed threshold        |          0.161968  |         0.158898  |          0.165038  |                 nan |
| High threat + slow replenishment | Event-aware PI              |          0.217725  |         0.214748  |          0.220702  |                   8 |
| High threat + slow replenishment | Event-blind PI              |          0.165524  |         0.161976  |          0.169072  |                   7 |
| High threat + slow replenishment | Zeraati-style event-free PI |          0.13492   |         0.131519  |          0.138322  |                   6 |
| High threat + slow replenishment | MVT-inspired threshold      |         -0.495886  |        -0.503373  |         -0.488399  |                 nan |
| High threat + slow replenishment | Best fixed threshold        |          0.133427  |         0.130048  |          0.136806  |                 nan |

### Paired reward-rate differences

Positive values indicate that event-aware PI had a higher reward rate than the comparison policy:

| scenario                         | comparison                                       | baseline                    |   mean_difference |   sd_paired_difference |   ci95_approx_low |   ci95_approx_high |   n_paired_seeds |
|:---------------------------------|:-------------------------------------------------|:----------------------------|------------------:|-----------------------:|------------------:|-------------------:|-----------------:|
| Reference                        | Event-aware PI minus Event-blind PI              | Event-blind PI              |         0.0509456 |             0.0138626  |         0.0448701 |          0.0570212 |               20 |
| Reference                        | Event-aware PI minus Zeraati-style event-free PI | Zeraati-style event-free PI |         0.0701917 |             0.0114235  |         0.0651851 |          0.0751982 |               20 |
| Reference                        | Event-aware PI minus MVT-inspired threshold      | MVT-inspired threshold      |         0.144884  |             0.0170092  |         0.137429  |          0.152339  |               20 |
| Reference                        | Event-aware PI minus Best fixed threshold        | Best fixed threshold        |         0.0650552 |             0.0112857  |         0.0601091 |          0.0700014 |               20 |
| High threat                      | Event-aware PI minus Event-blind PI              | Event-blind PI              |         0.0578973 |             0.00825283 |         0.0542803 |          0.0615142 |               20 |
| High threat                      | Event-aware PI minus Zeraati-style event-free PI | Zeraati-style event-free PI |         0.0778873 |             0.00744039 |         0.0746264 |          0.0811482 |               20 |
| High threat                      | Event-aware PI minus MVT-inspired threshold      | MVT-inspired threshold      |         0.208445  |             0.0171356  |         0.200935  |          0.215955  |               20 |
| High threat                      | Event-aware PI minus Best fixed threshold        | Best fixed threshold        |         0.0772828 |             0.00851608 |         0.0735505 |          0.0810151 |               20 |
| Slow replenishment               | Event-aware PI minus Event-blind PI              | Event-blind PI              |         0.0421521 |             0.00690612 |         0.0391253 |          0.0451788 |               20 |
| Slow replenishment               | Event-aware PI minus Zeraati-style event-free PI | Zeraati-style event-free PI |         0.0658178 |             0.00969748 |         0.0615677 |          0.0700679 |               20 |
| Slow replenishment               | Event-aware PI minus MVT-inspired threshold      | MVT-inspired threshold      |         0.540968  |             0.0283082  |         0.528561  |          0.553374  |               20 |
| Slow replenishment               | Event-aware PI minus Best fixed threshold        | Best fixed threshold        |         0.0727842 |             0.00942976 |         0.0686514 |          0.076917  |               20 |
| High threat + slow replenishment | Event-aware PI minus Event-blind PI              | Event-blind PI              |         0.0522009 |             0.00841435 |         0.0485132 |          0.0558887 |               20 |
| High threat + slow replenishment | Event-aware PI minus Zeraati-style event-free PI | Zeraati-style event-free PI |         0.0828043 |             0.0096605  |         0.0785704 |          0.0870382 |               20 |
| High threat + slow replenishment | Event-aware PI minus MVT-inspired threshold      | MVT-inspired threshold      |         0.713611  |             0.0193267  |         0.705141  |          0.722081  |               20 |
| High threat + slow replenishment | Event-aware PI minus Best fixed threshold        | Best fixed threshold        |         0.0842981 |             0.00987964 |         0.0799682 |          0.088628  |               20 |

### Policy-iteration convergence

| Scenario | Event-aware passes | Event-blind passes | Zeraati-style event-free passes |
|---|---:|---:|---:|
| Reference | 7 | 8 | 7 |
| High threat | 8 | 7 | 6 |
| Slow replenishment | 8 | 7 | 7 |
| High threat + slow replenishment | 8 | 7 | 6 |

## Interpretation and limitations

The most direct contrasts are event-aware PI versus event-blind PI, and event-aware PI versus the Zeraati-style event-free PI adapted here. The latter has no persistent phase and receives no boundary cue. However, it is not a replication of the original Zeraati task: it shares the exploit/leave action set and broad average-reward policy-iteration approach, but uses the present task's resource discretization, hidden threat/recovery process, reward costs, action durations, and fixed cyclic patch order.

The event-aware agent receives the true persistent phase label rather than learning an event detector. The event-blind and event-free MDPs use phase-prior aggregation based on a neutral 50:50 action mixture, an approximation that can discard information and can make their observation-level process non-Markovian. Because the phase prior is not conditioned on the policy being evaluated, the event-free baseline is not an exact solution to the underlying partially observable problem. Therefore, the results test the benefit of explicit event-state access under these assumptions; they do not prove that a sufficiently expressive history-sensitive or belief-state world model could not infer the same situation. The next key control is a history-sensitive event-free baseline trained with the same observations and interaction budget.

Approximate confidence intervals use a normal critical value (1.96); inferential claims should be strengthened with more seeds, paired statistical tests, and sensitivity analyses over hazard rates, risk costs, replenishment parameters, event-cue reliability, state discretization, and aggregation priors.

## Figures

- `figures/01_reward_rate_comparison.png`: reward-rate comparison for all five policies.
- `figures/02_event_awareness_advantage.png`: event-aware minus event-blind and event-free PI reward-rate differences.
- `figures/03_action_fractions_by_phase.png`: exploit/leave choices by true ecological phase for all three PI policies.
- `figures/04_policy_iteration_convergence.png`: changed greedy states by iteration for the three PI policies.
- `figures/05_threshold_tuning.png`: fixed-threshold tuning on separate seeds.
- `scenario_phase_priors.csv`: scenario-specific phase-prior weights used for approximate latent-state aggregation.

## Reference

Zeraati, R., Oña Jodar, T., Safavi, S., Cruz, B., Poo, C., & Dayan, P. (2025). *Optimal Foraging by Learning the World Model*. CCN 2025 conference abstract.
